import { analyzeEvidence, mergeTechnologyDetections, summarizeTechnologies } from "../shared/detector.js";
import { lookupTechnologyVulnerabilities, summarizeVulnerabilities, vulnerabilityCacheKey } from "../shared/vulnerabilities.js";
import { collectCatalogProperties } from "../shared/safe-properties.js";
import { isExactVersion } from "../shared/version.js";
import { analyzeOpenWappEvidence, OPENWAPP_CATALOG_SIZE, OPENWAPP_REQUIREMENTS } from "../vendor/openwapp-engine.js";

const RESULT_PREFIX = "scanResult:";
const HEADER_PREFIX = "responseHeaders:";
const SETTINGS_KEY = "settings";
const CACHE_KEY = "cveCache";
const CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const MAX_CVE_LOOKUPS = 12;
const AUTO_SETTLE_MS = 2_200;
const MANUAL_SETTLE_MS = 900;

async function settings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return {
    enabled: stored[SETTINGS_KEY]?.enabled !== false,
    autoScan: stored[SETTINGS_KEY]?.autoScan !== false,
    checkCves: stored[SETTINGS_KEY]?.checkCves !== false,
    excludedHosts: Array.isArray(stored[SETTINGS_KEY]?.excludedHosts) ? stored[SETTINGS_KEY].excludedHosts : []
  };
}

async function saveSettings(next) {
  const clean = {
    enabled: next.enabled !== false,
    autoScan: next.autoScan !== false,
    checkCves: next.checkCves !== false,
    excludedHosts: [...new Set((next.excludedHosts || []).map((item) => String(item).toLowerCase()).filter(Boolean))].sort()
  };
  await chrome.storage.local.set({ [SETTINGS_KEY]: clean });
  return clean;
}

function isSupportedUrl(url = "") {
  return /^https?:\/\//i.test(url);
}

function hostname(url = "") {
  try { return new URL(url).hostname.toLowerCase(); }
  catch { return ""; }
}

function isExcluded(url, excludedHosts) {
  const host = hostname(url);
  return excludedHosts.some((entry) => host === entry || host.endsWith(`.${entry}`));
}

async function setBadge(tabId, result = null, state = "") {
  let text = "";
  let color = "#1c9f91";
  let title = "StackSentry";
  if (state === "scanning") {
    text = "…";
    color = "#4267d5";
    title = "StackSentry is analyzing this site";
  } else if (state === "excluded") {
    text = "×";
    color = "#667085";
    title = "StackSentry auto-scan is excluded on this site";
  } else if (result) {
    text = String(Math.min(99, result.summary.technologies.total));
    const vulnerable = result.summary.vulnerabilities.total;
    color = vulnerable ? "#e5485d" : "#1c9f91";
    title = vulnerable
      ? `StackSentry: ${result.summary.technologies.total} technologies · ${vulnerable} known vulnerabilities`
      : `StackSentry: ${result.summary.technologies.total} technologies detected`;
  }
  await Promise.all([
    chrome.action.setBadgeText({ tabId, text }).catch(() => {}),
    chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {}),
    chrome.action.setTitle({ tabId, title }).catch(() => {})
  ]);
}

function headerObject(responseHeaders = []) {
  const output = {};
  for (const header of responseHeaders) {
    const name = String(header.name || "").toLowerCase();
    if (!name || name === "set-cookie") continue;
    const value = String(header.value || "");
    output[name] = output[name] ? `${output[name]}, ${value}` : value;
  }
  return output;
}

chrome.webRequest.onHeadersReceived.addListener((details) => {
  if (details.tabId < 0 || details.type !== "main_frame") return;
  void chrome.storage.session.set({
    [`${HEADER_PREFIX}${details.tabId}`]: {
      url: details.url,
      statusCode: details.statusCode,
      headers: headerObject(details.responseHeaders),
      capturedAt: Date.now()
    }
  });
}, { urls: ["http://*/*", "https://*/*"], types: ["main_frame"] }, ["responseHeaders"]);

async function collectDomEvidence(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    args: [OPENWAPP_REQUIREMENTS.cookie, OPENWAPP_REQUIREMENTS.domExists, OPENWAPP_REQUIREMENTS.domText, OPENWAPP_REQUIREMENTS.domAttribute, OPENWAPP_REQUIREMENTS.domProperty],
    func: (cookieNames, existsSelectors, textSelectors, attributeRequirements, propertyRequirements) => {
      const MAX_HTML = 1_500_000;
      const html = document.documentElement?.outerHTML || "";
      const boundedText = (nodes, limit) => {
        let output = "";
        for (const node of nodes) {
          const value = node.textContent || "";
          if (!value) continue;
          output += `${value.slice(0, Math.max(0, limit - output.length))}\n`;
          if (output.length >= limit) break;
        }
        return output;
      };
      const select = (selector, all = false) => {
        try { return all ? [...document.querySelectorAll(selector)].slice(0, 12) : document.querySelector(selector); }
        catch { return all ? [] : null; }
      };
      const primitive = (value) => {
        if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value).slice(0, 500);
        return value == null ? "" : "true";
      };
      const exactCookieNames = new Set(cookieNames.filter((name) => !name.includes("*")));
      const cookieGlobs = cookieNames.filter((name) => name.includes("*")).map((name) => new RegExp(`^${name.replace(/[\\^$.+?()[\]{}|]/g, "\\$&").replaceAll("*", ".*")}$`, "s"));
      const cookies = {};
      for (const pair of String(document.cookie || "").split(/;\s*/).slice(0, 300)) {
        const separator = pair.indexOf("=");
        const rawName = separator < 0 ? pair : pair.slice(0, separator);
        const name = rawName.trim().toLowerCase();
        if (!name || (!exactCookieNames.has(name) && !cookieGlobs.some((glob) => glob.test(name)))) continue;
        const value = separator < 0 ? "true" : pair.slice(separator + 1).slice(0, 500) || "true";
        (cookies[name] ||= []).push(value);
      }
      const domExists = existsSelectors.filter((selector) => select(selector));
      const domText = Object.fromEntries(textSelectors.map((selector) => {
        const values = select(selector, true).map((element) => (element.textContent || "").trim().slice(0, 500)).filter(Boolean);
        return [selector, [...new Set(values)]];
      }).filter(([, values]) => values.length));
      const domAttribute = Object.fromEntries(attributeRequirements.map(([selector, attributes]) => {
        const elements = select(selector, true);
        const values = Object.fromEntries(attributes.map((attribute) => [attribute, [...new Set(elements.map((element) => element.getAttribute(attribute) || "").filter(Boolean).map((value) => value.slice(0, 500)))]]).filter(([, found]) => found.length));
        return [selector, values];
      }).filter(([, values]) => Object.keys(values).length));
      const domProperty = Object.fromEntries(propertyRequirements.map(([selector, properties]) => {
        const elements = select(selector, true);
        const values = Object.fromEntries(properties.map((property) => [property, [...new Set(elements.map((element) => {
          const descriptor = Object.getOwnPropertyDescriptor(element, property);
          return descriptor && "value" in descriptor ? primitive(descriptor.value) : "";
        }).filter(Boolean))]]).filter(([, found]) => found.length));
        return [selector, values];
      }).filter(([, values]) => Object.keys(values).length));
      return {
        title: document.title,
        url: location.href,
        html: html.slice(0, MAX_HTML),
        htmlTruncated: html.length > MAX_HTML,
        scripts: [...document.scripts].slice(0, 600).map((script) => ({ src: script.src || "", type: script.type || "" })),
        links: [...document.querySelectorAll("link[href]")].slice(0, 600).map((link) => ({ href: link.href, rel: link.rel || "" })),
        inlineScripts: boundedText([...document.scripts].filter((script) => !script.src), 300_000),
        styles: boundedText([...document.querySelectorAll("style")], 200_000),
        text: (document.body?.innerText || "").slice(0, 200_000),
        resources: performance.getEntriesByType("resource").slice(0, 1200).map((entry) => ({
          name: entry.name || "",
          initiatorType: entry.initiatorType || ""
        })),
        meta: [...document.querySelectorAll("meta")].slice(0, 250).map((meta) => ({
          name: meta.name || "",
          property: meta.getAttribute("property") || "",
          httpEquiv: meta.httpEquiv || "",
          content: (meta.content || "").slice(0, 500)
        })),
        cookies,
        domExists,
        domText,
        domAttribute,
        domProperty
      };
    }
  });
  return result;
}

async function collectGlobalEvidence(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    args: [OPENWAPP_REQUIREMENTS.js],
    func: collectCatalogProperties
  });
  const js = result || {};
  return {
    jquery: js["jQuery.fn.jquery"] || js["$.fn.jquery"] || "",
    select2: js["jQuery.fn.select2"] || js["$.fn.select2"] || "",
    popper: js["Popper.version"] || js["Popper.Defaults"] || "",
    fontawesome: js.FontAwesome || "",
    react: js["React.version"] || "",
    nextjs: js.__NEXT_DATA__ || "",
    vue: js["Vue.version"] || "",
    nuxt: js.__NUXT__ || "",
    angular: js["angular.version.full"] || "",
    lodash: js["_.VERSION"] || "",
    axios: js["axios.VERSION"] || "",
    moment: js["moment.version"] || "",
    bootstrap: js["bootstrap.Tooltip.VERSION"] || js["jQuery.fn.tooltip.Constructor.VERSION"] || "",
    gsap: js["gsap.version"] || "",
    alpine: js["Alpine.version"] || "",
    requirejs: js["requirejs.version"] || "",
    sentry: js["Sentry.SDK_VERSION"] || js.__SENTRY__ || "",
    js
  };
}

function uniqueBy(items, key) {
  return [...new Map(items.filter(Boolean).map((item) => [key(item), item])).values()];
}

function mergeNestedEvidence(first, second) {
  if (Array.isArray(first) || Array.isArray(second)) return [...new Set([...(first || []), ...(second || [])])];
  if (first && second && typeof first === "object" && typeof second === "object") {
    const output = {};
    for (const name of new Set([...Object.keys(first), ...Object.keys(second)])) output[name] = mergeNestedEvidence(first[name], second[name]);
    return output;
  }
  return second ?? first;
}

function mergeTextSamples(first = "", second = "", limit) {
  if (!first || first === second) return String(second || first).slice(0, limit);
  const half = Math.floor((limit - 1) / 2);
  return `${String(first).slice(0, half)}\n${String(second).slice(0, limit - half - 1)}`;
}

function mergeEvidencePasses(first, second) {
  if (!second) return first;
  return {
    ...first,
    ...second,
    html: mergeTextSamples(first.html, second.html, 1_500_000),
    text: mergeTextSamples(first.text, second.text, 200_000),
    inlineScripts: mergeTextSamples(first.inlineScripts, second.inlineScripts, 300_000),
    styles: mergeTextSamples(first.styles, second.styles, 200_000),
    scripts: uniqueBy([...(first.scripts || []), ...(second.scripts || [])], (item) => `${item.src || ""}\0${item.type || ""}`),
    links: uniqueBy([...(first.links || []), ...(second.links || [])], (item) => `${item.href || ""}\0${item.rel || ""}`),
    resources: uniqueBy([...(first.resources || []), ...(second.resources || [])], (item) => `${item.name || ""}\0${item.initiatorType || ""}`),
    meta: uniqueBy([...(first.meta || []), ...(second.meta || [])], (item) => `${item.name || ""}\0${item.property || ""}\0${item.httpEquiv || ""}\0${item.content || ""}`),
    cookies: mergeNestedEvidence(first.cookies, second.cookies),
    domExists: [...new Set([...(first.domExists || []), ...(second.domExists || [])])],
    domText: mergeNestedEvidence(first.domText, second.domText),
    domAttribute: mergeNestedEvidence(first.domAttribute, second.domAttribute),
    domProperty: mergeNestedEvidence(first.domProperty, second.domProperty),
    htmlTruncated: Boolean(first.htmlTruncated || second.htmlTruncated)
  };
}

function mergeGlobalPasses(first = {}, second = {}) {
  return { ...first, ...second, js: { ...(first.js || {}), ...(second.js || {}) } };
}

const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

async function collectEvidencePass(tabId) {
  const [dom, globals] = await Promise.all([
    collectDomEvidence(tabId),
    collectGlobalEvidence(tabId).catch(() => ({}))
  ]);
  return { dom, globals };
}

async function cachedLookup(technology) {
  const key = vulnerabilityCacheKey(technology);
  if (!key) return lookupTechnologyVulnerabilities(technology);
  const stored = await chrome.storage.local.get(CACHE_KEY);
  const cache = stored[CACHE_KEY] || {};
  const existing = cache[key];
  if (existing && Date.now() - existing.savedAt < CACHE_TTL_MS) return { ...existing.result, cached: true };
  const result = await lookupTechnologyVulnerabilities(technology);
  cache[key] = { savedAt: Date.now(), result };
  const entries = Object.entries(cache).sort((a, b) => b[1].savedAt - a[1].savedAt).slice(0, 300);
  await chrome.storage.local.set({ [CACHE_KEY]: Object.fromEntries(entries) });
  return result;
}

async function addVulnerabilities(technologies, enabled) {
  const unqueriedStatus = (item) => !item.version ? "version-unknown" : !isExactVersion(item.version) ? "version-inexact" : "disabled";
  if (!enabled) return technologies.map((item) => ({ ...item, vulnerabilityStatus: unqueriedStatus(item), vulnerabilities: [] }));
  const eligible = technologies.filter((item) => isExactVersion(item.version) && (item.package || item.cpe));
  const candidates = eligible.slice(0, MAX_CVE_LOOKUPS);
  const candidateIds = new Set(candidates.map((item) => item.id));
  if (!candidates.length) return technologies.map((item) => ({ ...item, vulnerabilityStatus: !item.version ? "version-unknown" : !isExactVersion(item.version) ? "version-inexact" : "unsupported", vulnerabilities: [] }));
  const results = new Map();
  for (const technology of candidates) {
    try {
      results.set(technology.id, await cachedLookup(technology));
      if (technology.cpe) await new Promise((resolve) => setTimeout(resolve, 650));
    } catch (error) {
      results.set(technology.id, { status: "error", error: error?.message || String(error), vulnerabilities: [] });
    }
  }
  return technologies.map((technology) => {
    const result = results.get(technology.id);
    if (!result) {
      const vulnerabilityStatus = !technology.version ? "version-unknown"
        : !isExactVersion(technology.version) ? "version-inexact"
        : (technology.package || technology.cpe) && !candidateIds.has(technology.id) ? "lookup-limit"
        : "unsupported";
      return { ...technology, vulnerabilityStatus, vulnerabilities: [] };
    }
    return {
      ...technology,
      vulnerabilityStatus: result.status,
      vulnerabilitySource: result.source || "",
      vulnerabilityError: result.error || "",
      vulnerabilityCheckedAt: result.checkedAt || "",
      vulnerabilityQuery: result.query || null,
      vulnerabilities: result.vulnerabilities || [],
      cveCached: Boolean(result.cached)
    };
  });
}

async function scanTab(tabId, options = {}) {
  const tab = await chrome.tabs.get(tabId);
  if (!isSupportedUrl(tab.url)) throw new Error("Open a normal HTTP or HTTPS website first");
  const currentSettings = await settings();
  if (!currentSettings.enabled) throw new Error("StackSentry is turned off");
  if (!options.force && isExcluded(tab.url, currentSettings.excludedHosts)) {
    await setBadge(tabId, null, "excluded");
    throw new Error("This site is excluded from automatic scanning");
  }
  await setBadge(tabId, null, "scanning");
  const settleMs = Math.max(0, Math.min(5_000, Number(options.settleMs) || 0));
  const [initialPass, headerState] = await Promise.all([
    collectEvidencePass(tabId),
    chrome.storage.session.get(`${HEADER_PREFIX}${tabId}`)
  ]);
  let dom = initialPass.dom;
  let globals = initialPass.globals;
  let collectionPasses = 1;
  if (settleMs) {
    await wait(settleMs);
    const latestTab = await chrome.tabs.get(tabId);
    const latestSettings = await settings();
    if (latestTab.url !== tab.url) throw new Error("Page changed while StackSentry was collecting evidence");
    if (!latestSettings.enabled) throw new Error("StackSentry was turned off during analysis");
    if (!options.force && isExcluded(tab.url, latestSettings.excludedHosts)) throw new Error("This site was excluded during analysis");
    const settledPass = await collectEvidencePass(tabId);
    dom = mergeEvidencePasses(initialPass.dom, settledPass.dom);
    globals = mergeGlobalPasses(initialPass.globals, settledPass.globals);
    collectionPasses = 2;
  }
  const captured = headerState[`${HEADER_PREFIX}${tabId}`];
  const headers = captured?.url === tab.url ? captured.headers : {};
  const evidence = { ...dom, globals, js: globals.js || {}, headers };
  const detected = mergeTechnologyDetections(analyzeEvidence(evidence), analyzeOpenWappEvidence(evidence)).map((item) => ({ ...item, versionExact: isExactVersion(item.version) }));
  const shouldCheckCves = options.checkCves ?? currentSettings.checkCves;
  const technologies = options.deferCves && shouldCheckCves
    ? detected.map((item) => ({ ...item, vulnerabilityStatus: !item.version ? "version-unknown" : !item.versionExact ? "version-inexact" : (item.package || item.cpe) ? "pending" : "unsupported", vulnerabilities: [] }))
    : await addVulnerabilities(detected, shouldCheckCves);
  const result = {
    scanId: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
    tabId,
    url: dom.url,
    title: dom.title || tab.title || hostname(tab.url),
    host: hostname(dom.url),
    scannedAt: new Date().toISOString(),
    htmlTruncated: Boolean(dom.htmlTruncated),
    statusCode: captured?.statusCode || null,
    catalogSize: OPENWAPP_CATALOG_SIZE,
    collectionPasses,
    settleDelayMs: settleMs,
    technologies,
    cveLookupPending: Boolean(options.deferCves && shouldCheckCves),
    summary: {
      technologies: summarizeTechnologies(technologies),
      vulnerabilities: summarizeVulnerabilities(technologies)
    }
  };
  await chrome.storage.session.set({ [`${RESULT_PREFIX}${tabId}`]: result });
  await setBadge(tabId, result);
  if (result.cveLookupPending) {
    void (async () => {
      const enriched = await addVulnerabilities(detected, true);
      const [latestTab, latestSettings, latestResult] = await Promise.all([chrome.tabs.get(tabId).catch(() => null), settings(), getResult(tabId)]);
      if (!latestTab || latestTab.url !== result.url || !latestSettings.enabled || isExcluded(result.url, latestSettings.excludedHosts) || latestResult?.scanId !== result.scanId) return;
      result.technologies = enriched;
      result.cveLookupPending = false;
      result.summary.technologies = summarizeTechnologies(enriched);
      result.summary.vulnerabilities = summarizeVulnerabilities(enriched);
      await chrome.storage.session.set({ [`${RESULT_PREFIX}${tabId}`]: result });
      await setBadge(tabId, result);
    })().catch(() => {});
  }
  return result;
}

async function getResult(tabId) {
  const stored = await chrome.storage.session.get(`${RESULT_PREFIX}${tabId}`);
  return stored[`${RESULT_PREFIX}${tabId}`] || null;
}

async function openReport(tabId) {
  return chrome.tabs.create({ url: chrome.runtime.getURL(`report/index.html?tab=${encodeURIComponent(tabId)}`) });
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab || null;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  void (async () => {
    try {
      const tabId = Number.isInteger(message.tabId) ? message.tabId : sender.tab?.id;
      let data;
      if (message.type === "getActive") {
        const tab = await activeTab();
        data = tab ? { tab: { id: tab.id, title: tab.title, url: tab.url }, result: await getResult(tab.id), settings: await settings() } : null;
      } else if (message.type === "scan") {
        const target = Number.isInteger(tabId) ? tabId : (await activeTab())?.id;
        const checkCves = message.checkCves !== false;
        data = await scanTab(target, { force: true, checkCves, deferCves: checkCves, settleMs: MANUAL_SETTLE_MS });
      } else if (message.type === "getResult") {
        data = await getResult(tabId);
      } else if (message.type === "openReport") {
        data = await openReport(tabId);
      } else if (message.type === "updateSettings") {
        data = await saveSettings({ ...(await settings()), ...message.settings });
        if (!data.enabled) {
          const tabs = await chrome.tabs.query({});
          await Promise.all(tabs.map((tab) => setBadge(tab.id)));
        }
      } else if (message.type === "toggleExclude") {
        const current = await settings();
        const host = hostname(message.url);
        const excluded = new Set(current.excludedHosts);
        if (excluded.has(host)) excluded.delete(host); else excluded.add(host);
        data = await saveSettings({ ...current, excludedHosts: [...excluded] });
        const target = Number.isInteger(tabId) ? tabId : (await activeTab())?.id;
        if (excluded.has(host)) await setBadge(target, null, "excluded"); else void scanTab(target, { force: true, settleMs: MANUAL_SETTLE_MS });
      } else {
        throw new Error("Unknown StackSentry request");
      }
      sendResponse({ ok: true, data });
    } catch (error) {
      sendResponse({ ok: false, error: error?.message || String(error) });
    }
  })();
  return true;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !isSupportedUrl(tab.url)) return;
  void settings().then((current) => {
    if (!current.enabled) return setBadge(tabId);
    if (!current.autoScan) return setBadge(tabId);
    if (isExcluded(tab.url, current.excludedHosts)) return setBadge(tabId, null, "excluded");
    return scanTab(tabId, { deferCves: true, settleMs: AUTO_SETTLE_MS }).catch(() => setBadge(tabId));
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void chrome.storage.session.remove([`${RESULT_PREFIX}${tabId}`, `${HEADER_PREFIX}${tabId}`]);
});

chrome.commands.onCommand.addListener((command) => {
  if (command !== "scan-current-site") return;
  void activeTab().then(async (tab) => {
    if (!tab) return;
    await scanTab(tab.id, { force: true, settleMs: MANUAL_SETTLE_MS });
    await openReport(tab.id);
  }).catch(() => {});
});

chrome.runtime.onInstalled.addListener(() => void settings().then(saveSettings));
